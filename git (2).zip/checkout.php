<?php
require __DIR__ . '/public/checkout.php';
